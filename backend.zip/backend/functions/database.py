import json
import random

#Get recent messages
def get_recent_msgs():

    #Define file name and learn instruction
    file_name = "stored_data.json"
    learn_instruction = {
        "role": "system",
        "content": "You are interviewing the user for a software engineer position. Ask short questions that are relevant to a junior position. Your name is Rachel. The user is called \"Insert Name Here\". Keep your answers to under 30 words."
    }

    #Initialize Messages
    messages = []

    #Add a random element
    x = random.uniform(0,1)
    if x < 0.5:
        learn_instruction["content"] = learn_instruction["content"] + " Your response will be meaningful and may sometimes include dry humor."
    else:
        learn_instruction["content"] = learn_instruction["content"] + " Your response will include a challenging question."

    #Append instruction to message
    messages.append(learn_instruction)

    #Get last messages
    try:
        with open(file_name) as user_file:
            data = json.load(user_file)

            # Append the last 5 items of data
            if data:
                if len(data) < 5:
                    for item in data:
                        messages.append(item)
                else:
                    for item in data[-5:]:
                        messages.append(item)
    except Exception as e:
        print(e)
        pass

    #Return
    return messages

# Store messages
def store_messages(request_message, response_message):

    #Define the file name
    file_name = "stored_data.json"

    #Get recent messages
    messages = get_recent_msgs()[1:]

    #Add messages to data
    user_messages = {"role": "user", "content": request_message}
    assistant_messages = {"role": "assistant", "content": response_message}
    messages.append(user_messages)
    messages.append(assistant_messages)

    #Save the updated file
    with open(file_name, "w") as f:
        json.dump(messages, f)

#Reset messages
def reset_messages():
    #Overwrite current file with nothing
    open("stored_data.json", "w")
    